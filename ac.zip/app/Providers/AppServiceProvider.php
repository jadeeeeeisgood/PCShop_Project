<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\URL;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // TEMPORARILY DISABLE HTTPS FORCING TO FIX DEPLOYMENT
        // Force HTTPS URLs in production
        // if (app()->environment('production')) {
        //     URL::forceScheme('https');
        //     URL::forceRootUrl(config('app.url'));
        // }

        // Set timezone
        date_default_timezone_set('Asia/Ho_Chi_Minh');
    }
}
