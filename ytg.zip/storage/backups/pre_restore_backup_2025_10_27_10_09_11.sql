-- Pre-Restore Backup
-- Created: 2025-10-27 10:09:11

-- Current Products Backup
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (1, 1, 'PC Gaming Performance RTX 4060', 'pc-gaming-performance-rtx-4060', 'PC Gaming hiệu năng cao với RTX 4060, Intel i5-12400F, RAM 16GB, SSD 512GB', 21990000.00, 50, '', NULL, NULL, 1, 1, 0, '2025-10-26 06:44:19', '2025-10-26 06:44:19');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (2, 3, 'HP Pavilion 16', 'hp-pavilion-16', 'Laptop HP Pavilion 16 inch, Intel Core i5, RAM 8GB, SSD 512GB', 16000000.00, 30, '', NULL, NULL, 1, 1, 0, '2025-10-26 06:44:19', '2025-10-26 06:44:19');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (3, 4, 'PlayStation 5', 'playstation-5', 'Sony PlayStation 5 Console - Thế hệ game mới', 13300000.00, 20, '', NULL, NULL, 1, 1, 0, '2025-10-26 06:44:19', '2025-10-26 06:44:19');
