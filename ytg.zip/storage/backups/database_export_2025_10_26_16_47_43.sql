-- PC Shop Database Export
-- Generated on: 2025-10-26 16:47:43

-- Categories Data
DELETE FROM categories WHERE id > 0;
INSERT INTO categories (id, name, slug, created_at, updated_at) VALUES (1, 'Gaming PC', 'gaming-pc', '2025-10-14 13:42:00', '2025-10-26 06:57:04');
INSERT INTO categories (id, name, slug, created_at, updated_at) VALUES (2, 'Office PC', 'office-pc', '2025-10-14 13:42:00', '2025-10-26 06:57:12');
INSERT INTO categories (id, name, slug, created_at, updated_at) VALUES (3, 'Laptop', 'laptop', '2025-10-14 13:42:00', '2025-10-26 06:57:16');
INSERT INTO categories (id, name, slug, created_at, updated_at) VALUES (4, 'Linh kiện', 'linh-kien', '2025-10-14 13:42:00', '2025-10-26 07:08:09');
INSERT INTO categories (id, name, slug, created_at, updated_at) VALUES (5, 'Gaming Gear', 'gaming-gear', '2025-10-14 13:42:00', '2025-10-26 07:08:31');
INSERT INTO categories (id, name, slug, created_at, updated_at) VALUES (7, 'PS5', 'ps5', '2025-10-26 07:09:14', '2025-10-26 07:09:14');

-- Products Data
DELETE FROM products WHERE id > 0;
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (12, 1, 'PC AMD GAMING SUPER LUXURY RYZEN 9 9950X3D - RTX 5090 32GB OC Edition (All NEW - Bảo hành 36 tháng)', 'pc-amd-gaming-super-luxury-ryzen-9-9950x3d-rtx-5090-32gb-oc-edition-all-new-bao-hanh-36-thang', 'CPU AMD Ryzen 9 9950X3D (16 nhân 32 luồng, 4.3GHz up to 5.7GHz, 144MB Cache)
Mainboard Asus ROG STRIX X870E-E Gaming Wifi DDR5
Ram G.SKILL Trident Z5 RGB 64GB (32GBx2) BUS 6000MHz DDR5
Ổ cứng SSD Samsung 990 PRO 2TB M.2 NVMe M.2 2280 PCIe Gen4.0 x4
Nguồn máy tính SuperFlower Leadex VII PRO 1200W ATX3.1 80 Plus Platinum SF-1200F14XP
Card màn hình ASUS ROG Astral GeForce RTX 5090 32GB GDDR7 OC Edition
Tản nhiệt nước TRYX PANORAMA ARGB 360 (Màn AMOLED 6.5/Bơm ASETEK 8)
Vỏ case HYTE Y70 - Black (ATX/Mid Tower/Màu đen)
Phụ kiện: Fan Case JONSBO ZA-360 ARGB Black, Dây nguồn nối dài Lian Li Strimer Plus 24 Pin ARGB', 198980000.00, 36, 'img/1761463449_h71zLpRwNV.jpg', '[\"img/1761463449_xnMiCV8C5W.jpg\", \"img/1761463449_C51KYlcAEA.jpg\", \"img/1761463449_4oZUvv2iAf.jpg\", \"img/1761463449_pSS0cKiQzF.jpg\"]', '', 1, 1, 0, '2025-10-26 07:24:09', '2025-10-26 07:24:09');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (13, 1, 'PC ROG STRIX GAMING LUXURY RYZEN 9 9950X3D - RTX 5090 32GB OC WHITE', 'pc-rog-strix-gaming-luxury-ryzen-9-9950x3d-rtx-5090-32gb-oc-white', 'CPU AMD Ryzen 9 9950X3D - TRAY NEW (16 nhân 32 luồng, up to 5.7GHz, 144MB Cache, AM5)
Mainboard ASUS X870-A ROG STRIX GAMING WIFI DDR5
RAM CORSAIR DOMINATOR PLATINUM RGB 64GB 5600MHz DDR5 (2x32GB) WHITE
SSD Samsung 9100 PRO 1TB M.2 NVMe M.2 2280 PCIe Gen5.0
Nguồn LIAN LI Edge series EG1300 - 1300W (ATX3.1/80+Platinum/Full Modular, Màu trắng)
Card màn hình ASUS ROG ASTRAL RTX 5090 32GB GAMING WHITE OC
Vỏ case LIAN LI O11 Dynamic Evo White (Mid Tower/Màu trắng)
Tản nhiệt nước TRYX PANORAMA ARGB 360 (Màn AMOLED 6.5/Bơm ASETEK 8) WHITE
Quạt tản nhiệt LIAN LI UNI FAN TL Wireless 120 WHITE (Bộ 3 cái/Màu trắng)', 186800000.00, 100, 'img/1761463519_haKhH73dZr.jpg', '[]', '', 0, 1, 0, '2025-10-26 07:25:19', '2025-10-26 07:25:19');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (14, 1, 'PC AMD SUPER LUXURY RYZEN 7 9800X3D - RTX 5080 16GB OC WHITE', 'pc-amd-super-luxury-ryzen-7-9800x3d-rtx-5080-16gb-oc-white', 'CPU AMD Ryzen 7 9800X3D (8 nhân 16 luồng, 4.7GHz up to 5.2GHz, 120W) - TRAY
Mainboard ASROCK X870 PRO RS WIFI DDR5
RAM G.SKILL RIPJAWS M5 32GB 6000MHz (2x16GB) DDR5 WHITE
Ổ cứng SSD KIOXIA PLUS 1TB NVMe M.2 PCIe Gen4
Nguồn máy tính Darkflash PMT850 850W (ATX3.1 & PCIe 5.1, 80 Plus Gold, Full Modular)
Card màn hình Colorful iGame GeForce RTX 5080 Ultra W OC 16GB GDDR7
Vỏ case ANTEC C8 ALU WHITE
Tản nhiệt nước Thermalright HYPER VISION 360 ARGB WHITE
Fan Case JONSBO ZA-360 ARGB WHITE', 78980000.00, 50, 'img/1761463628_NIymHsDCCj.jpg', '[\"img/1761463628_6XbLgtCrr2.jpg\", \"img/1761463628_LpHslVWmhj.jpg\", \"img/1761463628_Lld8AaJ30Y.jpg\"]', '', 0, 1, 0, '2025-10-26 07:27:08', '2025-10-26 07:27:08');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (15, 1, 'PC MINI GAMING LUXURY i5 12400F - RTX 4060 8GB OC WHITE (All NEW - Bảo hành 36 tháng)', 'pc-mini-gaming-luxury-i5-12400f-rtx-4060-8gb-oc-white-all-new-bao-hanh-36-thang', 'CPU Intel Core i5-12400F (Upto 4.4GHz, 6 nhân 12 luồng, 18MB Cache, 65W) - TRAY
Mainboard ASUS B760M-K PRIME DDR4
RAM ADATA SPECTRIX D50 16GB 3200MHz DDR4 WHITE
Ổ cứng SSD SSTC Oceanic Whitetip E130 512GB M.2 2280 PCIe NVMe (Gen 3x4)
Nguồn AIGO VK650 - 650W (85 Plus/Active PFC/Single Rail)
Card màn hình ZOTAC GAMING RTX 4060 8GB Twin Edge OC White Edition
Vỏ case Jonsbo TK-1 White (Mid Tower/Màu trắng)
Tản nhiệt nước Thermalright AQUA ELITE V3 240 ARGB WHITE', 19980000.00, 3, 'img/1761463718_gPIDhkEINv.jpg', '[]', '', 0, 1, 0, '2025-10-26 07:28:38', '2025-10-26 07:28:38');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (16, 1, 'PC TTG GAMING LUXURY i5 14600KF - RTX 5070 12GB OC ULTRA WHITE (All NEW - Bảo hành 36 tháng)', 'pc-ttg-gaming-luxury-i5-14600kf-rtx-5070-12gb-oc-ultra-white-all-new-bao-hanh-36-thang', 'CPU Intel Core i5-14600KF (Up to 5.3GHz, 14 nhân 20 luồng, 24MB Cache) - TRAY
Mainboard MSI B760M GAMING PLUS WIFI DDR5
RAM G.SKILL RIPJAWS M5 32GB 6000MHz (2x16GB) DDR5 WHITE
Ổ cứng SSD WD GREEN 512GB NVMe M.2 PCIe Gen4
Nguồn máy tính AIGO GB750 - 750W (80 Plus Bronze, Màu đen)
Card màn hình Colorful RTX 5070 Ultra White OC 12GB
Vỏ case XIGMATEK META WHITE - kèm 4 fan ARGB WHITE
Tản nhiệt nước AIO Jonsbo TH-360 ARGB WHITE (màn hình hiển thị nhiệt độ)', 37680000.00, 551, 'img/1761463831_EAMRxNIVXJ.jpg', '[\"img/1761463831_O4wK6KI38v.jpg\", \"img/1761463831_BH4eVcb9Qr.jpg\", \"img/1761463831_m0gpCKGigF.jpg\", \"img/1761463831_FG2RJ0da1b.jpg\"]', '', 0, 1, 0, '2025-10-26 07:30:31', '2025-10-26 10:06:18');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (17, 2, 'PC TTG HOME OFFICE Core i3 10105 - RAM 8GB- SSD 256GB', 'pc-ttg-home-office-core-i3-10105-ram-8gb-ssd-256gb', 'CPU Intel Core i3-10105 (Intel LGA1200, 4 nhân 8 luồng, Base 3.7GHz, Turbo 4.4GHz, Cache 6MB)
Mainboard MSI H510M-B PRO II
RAM Team VulcanZ 8GB Bus 3200MHz DDR4
SSD TEAM CX2 256GB SATA
Nguồn máy tính AIGO VK550 - 500W
Vỏ case XIGMATEK XA-22
Bộ bàn phím + chuột Tomato S100
Tản nhiệt khí Jonsbo CR-1200', 6280000.00, 9999, 'img/1761463924_SrJomfRd7N.jpg', '[\"img/1761463924_tXvlFFRkfM.jpg\"]', '', 0, 1, 0, '2025-10-26 07:32:04', '2025-10-26 07:32:04');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (18, 2, 'PC TTG HOME OFFICE Core i5 12400 - RAM 16GB- SSD 256GB- Kèm Màn hình', 'pc-ttg-home-office-core-i5-12400-ram-16gb-ssd-256gb-kem-man-hinh', 'CPU Intel Core i5-12400 (Intel LGA1700, 6 nhân 12 luồng, Base 2.5GHz, Turbo 4.4GHz, Cache 18MB)
Mainboard ASROCK H610M-H M.2 DDR4
RAM Geil Spear EVO 16GB Bus 3200MHz DDR4
SSD TEAM CX2 256GB SATA
Nguồn máy tính AIGO VK550 - 500W
Vỏ case AIGO Q15 mATX USB 3.0
Bộ bàn phím + chuột Tomato S100
Tản nhiệt khí Jonsbo CR-1200
Màn hình Dark Flash G243FW (23.8 inch, FHD, IPS, 100Hz, 5ms)', 10680000.00, 100, 'img/1761464054_R760lrROEq.jpg', '[\"img/1761464054_zd6wJT3DDZ.jpg\"]', '', 1, 1, 1, '2025-10-26 07:34:14', '2025-10-26 10:19:46');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (19, 2, 'PC TTG HOME OFFICE Core i7 12700 - RAM 16GB- SSD 500GB- Kèm Màn hình', 'pc-ttg-home-office-core-i7-12700-ram-16gb-ssd-500gb-kem-man-hinh', 'CPU Intel Core i7-12700 (Intel LGA1700, 12 nhân 20 luồng, Base 3.6GHz, Turbo 4.9GHz, Cache 25MB)
Mainboard ASUS B760M-K PRIME D4
RAM Geil Spear EVO 16GB Bus 3200MHz DDR4
Ổ cứng SSD PNY CS1031 500GB M.2 2280 PCIe NVMe Gen3x4 (Đọc 2200MB/s – Ghi 1200MB/s)
Nguồn máy tính AIGO VK650 - 650W (80 Plus/Active PFC/Single Rail)
Vỏ case XIGMATEK NYX AIR 3F
Tản nhiệt khí ID-COOLING SE-214 BLACK
Bộ bàn phím + chuột Tomato S100
Màn hình Dark Flash G243FW (23.8 inch, FHD, IPS, 100Hz, 5ms)', 15880000.00, 114, 'img/1761464113_NAvRccxg23.jpg', '[]', '', 1, 1, 0, '2025-10-26 07:35:13', '2025-10-26 07:35:13');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (20, 2, 'PC TTG Home Office Hiệu Suất Cao Kèm Màn Hình - PTS - Gaming LOL, CS2, Fifa Ryzen 5 4600G', 'pc-ttg-home-office-hieu-suat-cao-kem-man-hinh-pts-gaming-lol-cs2-fifa-ryzen-5-4600g', 'CPU AMD Ryzen 5 4600G (3.7GHz Turbo up to 4.2GHz, 11MB Cache, 6 nhân 12 luồng, 65W, Socket AM4)
Mainboard MSI A520M-A PRO
RAM PNY XLR8 Gaming 16GB Bus 3200MHz DDR4
Ổ cứng SSD Crucial P3 500GB M.2 2280 PCIe NVMe (Gen 3x4)
Nguồn máy tính AIGO VK550 - 500W (Màu đen)
Vỏ case XIGMATEK XA-20
Màn hình VSP IPS 24 inch IP2407S', 9880000.00, 44, 'img/1761464229_JAJJP3oxfG.jpg', '[\"img/1761464229_XJs34LFoAq.jpg\", \"img/1761464229_ZHYR7GUUoj.jpg\", \"img/1761464229_IUYQZ2xGpJ.jpg\"]', '', 1, 1, 0, '2025-10-26 07:37:09', '2025-10-26 07:37:09');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (21, 4, '-22% OFF CPU AMD Ryzen 5 9600X - TRAY (3.9 GHz Boost 5.4 GHz | 6 nhân/ 12 luồng | 32 MB Cache)', '22-off-cpu-amd-ryzen-5-9600x-tray-39-ghz-boost-54-ghz-6-nhan-12-luong-32-mb-cache', 'Bộ vi xử lý AMD Ryzen 5 9600X (6 nhân 12 luồng, kiến trúc Zen 5, xung nhịp cơ bản 4.7GHz, Boost tối đa 5.3GHz, bộ nhớ đệm 6MB L2 + 32MB L3, hỗ trợ ép xung, socket AM5, PCIe 5.0, đồ họa tích hợp AMD Radeon™ Graphics – 2 nhân, 2200MHz, hỗ trợ RAM DDR5 kênh đôi tối đa 192GB, TDP 65W)', 6980000.00, 999, 'img/1761464380_IMu93Tnmj9.jpg', '[\"img/1761464380_FwpCKSdsFs.jpg\"]', '', 1, 1, 0, '2025-10-26 07:39:40', '2025-10-26 09:26:53');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (22, 4, 'CPU Intel Core i5-10400F - TRAY NEW (3.4GHz turbo up to 4.4Ghz, 6 nhân 12 luồng, 12MB Cache, 65W)', 'cpu-intel-core-i5-10400f-tray-new-34ghz-turbo-up-to-44ghz-6-nhan-12-luong-12mb-cache-65w', 'Bộ vi xử lý Intel Core i5-10400F (6 nhân 12 luồng, kiến trúc Comet Lake, socket LGA1200, xung nhịp cơ bản 3.4GHz, tối đa 4.4GHz, bộ nhớ đệm 12MB, tiến trình 14nm, hỗ trợ 64-bit, siêu phân luồng, bộ nhớ DDR4 2666MHz kênh đôi, PCIe 3.0, TDP 65W, không có đồ họa tích hợp)', 1980000.00, 2, 'img/1761464459_S3kGnfs5Yx.jpg', '[]', '', 1, 1, 0, '2025-10-26 07:40:59', '2025-10-26 07:40:59');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (23, 4, 'Card Màn Hình MSI GeForce RTX 5070 12G SHADOW 3X OC', 'card-man-hinh-msi-geforce-rtx-5070-12g-shadow-3x-oc', 'Dung lượng bộ nhớ: 12GB GDDR7
Extreme Performance: 2557 MHz (MSI Center)
Boost: 2542 MHz
Băng thông: 192-bit
Kết nối: DisplayPort x 3 (v2.1b), HDMI™ x 1
Nguồn yêu cầu: 650W
Bảo hành: 36 Tháng', 17680000.00, 36, 'img/1761464554_RZvblUkNTq.jpg', '[\"img/1761464554_knXju97zAS.jpg\", \"img/1761464554_Lb5KtRf1zy.jpg\", \"img/1761464554_wyI6itIVPb.jpg\"]', '', 1, 1, 0, '2025-10-26 07:42:34', '2025-10-26 07:42:34');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (24, 4, 'Card màn hình ASUS ROG ASTRAL RTX 5090 32GB GAMING WHITE OC', 'card-man-hinh-asus-rog-astral-rtx-5090-32gb-gaming-white-oc', '- Nhân đồ hoạ: NVIDIA® GeForce RTX™ 5090
 - Dung lượng bộ nhớ: 32Gb GDDR7
 - Số nhân CUDA : 21760
 - Nguồn đề xuất: 1000W
Bảo hành: 36 Tháng', 99980000.00, 100, 'img/1761464644_17SZjcbAGR.jpg', '[\"img/1761464644_yrZmLVii1J.jpg\", \"img/1761464644_xNSevFxU3o.jpg\", \"img/1761464644_lVMWfL9HeZ.jpg\", \"img/1761464644_GAIr5yRjB3.jpg\", \"img/1761464644_ZkDjyMmZpL.jpg\"]', '', 1, 1, 0, '2025-10-26 07:44:04', '2025-10-26 07:44:04');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (25, 4, '-24% OFF Mainboard Gigabyte Z890 AORUS ELITE WIFI7 ICE DDR5', '24-off-mainboard-gigabyte-z890-aorus-elite-wifi7-ice-ddr5', 'Socket: LGA1851 socket - Support for Intel® Core™ Ultra Processor
 Kích thước: ATX
 Khe cắm RAM: 4 khe (Tối đa 256GB)
Khe cắm mở rộng: 1 x PCI Express x16 slot (supporting PCIe 5.0 and running at x16 (PCIEX16)), 2 x PCI Express x16 slots (supporting PCIe 4.0 and running at x4 (PCIEX4_1, PCIEX4_2))
 Khe cắm ổ cứng: 4 x M.2 slots and 4 x SATA 6Gb/s ports
Bảo hành: 36 Tháng', 9899000.00, 55, 'img/1761464749_C2EQI80Ls5.jpg', '[\"img/1761464749_a0e4rNY46d.jpg\", \"img/1761464749_bh9IP8RRkp.jpg\"]', '', 0, 1, 0, '2025-10-26 07:45:49', '2025-10-26 07:45:49');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (26, 4, 'Mainboard Gigabyte B860M DS3H DDR5', 'mainboard-gigabyte-b860m-ds3h-ddr5', 'Chipset: Intel B860
CPU hỗ trợ: Intel Core Ultra
Socket: LGA 1851
Ram: 4 khe DDR5 ( tối đa 256GB)
Kích thước: ATX (24.4cm x 24.4cm
Bảo hành: 36 Tháng', 4299000.00, 78, 'img/1761464840_8VqOhF53tx.jpg', '[\"img/1761464840_1qnQbBK1pV.jpg\", \"img/1761464840_U2pHAiTeJi.jpg\", \"img/1761464840_90wvtW10f2.jpg\"]', '', 0, 1, 0, '2025-10-26 07:47:20', '2025-10-26 07:47:20');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (27, 5, 'Chuột Zowie U2 Wireless', 'chuot-zowie-u2-wireless', 'Chuột Gaming không dây BenQ Zowie U2
 - Wireless 2.4Ghz thông qua bộ thu / Dây USB
 - Thiết kế đối xứng. Hình dáng vát cong đều hai bên tối đa sự linh hoạt khi di chuyển nhiều góc độ.
 - Tối ưu cho kiểu cầm chuột Claw-Grip
 - Mắt cảm biến: Paw3395
 - Độ phân giải: 3200 DPI
 - Bộ thu kiêm đế sạc thuận tiện, đem lại độ trễ siêu thấp
 - Kết nối đơn giản không driver, plug and play
 - Thời lượng pin lên đến 70h
Bảo hành: 12 Tháng', 1890000.00, 257, 'img/1761465051_egYklIfaP8.jpg', '[\"img/1761465051_4GPCzr8DpD.jpg\", \"img/1761465051_Yu39rywHyQ.jpg\", \"img/1761465051_YlrEbSiMSV.jpg\", \"img/1761465051_eH8GhrkJOC.jpg\"]', '', 1, 1, 1, '2025-10-26 07:50:51', '2025-10-26 07:51:37');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (28, 5, 'Bàn phím cơ AULA F75 3 Mode Snow Blue Reaper switch', 'ban-phim-co-aula-f75-3-mode-snow-blue-reaper-switch', 'Bàn phím cơ AULA F75 3 Mode Snow Blue Reaper switch
- Độ bền: 60 triệu lần bấm
- Kết nối: 3 mode có dây Type-C & không dây 2.4G & BT
- Màu sắc: Tím nhạt+be+xanh lá
- Đèn nền: LED RGB 16,8 triệu màu, 16 loại hiệu ứng
- Loại switch: Reaper switch
- Hiệu ứng âm thanh khi gõ phím: Linear
- Hot-Swap
- Số lượng phím: 80
- Hành trình phím: 4.0mm
- Chất liệu keycap: Nhựa PBT
- Điện áp/dòng sạc: DC 5V-700mA
- Điện áp định mức: DC 3.7V (đầy đủ 4.2V)
- Dòng điện định mức: 230mA @3.7V (hiệu ứng ánh sáng mặc định); 15mA (tắt đèn nền)
- Dung lượng pin: Pin lithium 4000mAh có thể sạc lại
- Giao diện sạc: Type-C
- Kích thước bàn phím (L x W x H): 322.7 × 143.2 × 43.1 ± 0.5 mm
- Trọng lượng: Khoảng 975g (không có cáp/bộ thu)/ 1023g (với cáp/bộ thu)
- Phím FN đa chức năng
- Hệ điều hành tương thích: WINXP/WIN7/WIN8/WIN10/Android/IOS/MAC
- Phụ kiện kèm theo: Sách hướng dẫn sử dụng + Dây USB type-C + Dụng cụ thay switch + 2 switch tặng kèm
Bảo hành : 12 Tháng', 1250000.00, 125, 'img/1761465299_dNmLPBgpoh.jpg', '[\"img/1761465299_2CMc3E5Ehc.jpg\", \"img/1761465299_Ar0T4p6zov.jpg\", \"img/1761465299_xsTAkDCX67.jpg\"]', '', 1, 1, 0, '2025-10-26 07:54:59', '2025-10-26 09:39:09');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (29, 5, 'Bàn phím cơ Steelseries Apex Pro TKL US', 'ban-phim-co-steelseries-apex-pro-tkl-us', 'Chất liệu: Hợp kim nhôm
 Số phím: 87 phím
 Anti-Ghosting: 100%
 Đèn LED: RGB dynamic mỗi phím
 Trọng lượng: 1,7 lbs
 Kích thước: 355.44 x 139.26 x 40.44 mm
 Màn hình OLED: Có
 Phím điều khiển đa phương tiện: Có
 Độ bền: 100 triệu lượt nhấn
 Kê tay: Có
Bảo hành: 12 tháng', 1590000.00, 44, 'img/1761465596_G1ZXufhICq.jpg', '[\"img/1761465596_FeOMI70OgT.jpg\", \"img/1761465596_mAqI9shPOF.jpg\", \"img/1761465596_DNgh0A5U2D.jpg\"]', '', 0, 1, 0, '2025-10-26 07:59:56', '2025-10-26 07:59:56');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (30, 7, 'PS5 thường', 'ps5-thuong', 'Thường thôi', 1800000.00, 18, 'img/1761465695_jEZF3mwO6Q.jpg', '[]', '', 0, 1, 0, '2025-10-26 08:01:35', '2025-10-26 08:01:35');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (31, 7, 'PS5 Pro', 'ps5-pro', 'PRO', 3600000.00, 36, 'img/1761465731_hIOx21Z9Dc.jpg', '[]', '', 1, 1, 0, '2025-10-26 08:02:11', '2025-10-26 08:02:11');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (32, 7, 'PS5 Promax', 'ps5-promax', 'Promax', 36000000.00, 354, 'img/1761465768_7VluPBw192.jpg', '[]', '', 1, 1, 0, '2025-10-26 08:02:48', '2025-10-26 15:31:53');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (33, 7, 'Đĩa game PS5 Jurassic World Evolution 2', 'dia-game-ps5-jurassic-world-evolution-2', 'Mô tả: Trò chơi xây dựng và quản lý công viên khủng long với đồ họa 3D sinh động và cốt truyện hấp dẫn.', 900000.00, 7, 'img/1761465840_QAuetmVXCR.jpg', '[]', '', 0, 1, 1, '2025-10-26 08:04:00', '2025-10-26 15:31:52');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (34, 7, 'Tay cầm PS5 Dualsense Wireless Controller The Last Of Us Special Limited Edition', 'tay-cam-ps5-dualsense-wireless-controller-the-last-of-us-special-limited-edition', 'Mô tả: Tay cầm không dây thiết kế đặc biệt phiên bản The Last Of Us, mang lại trải nghiệm chơi game sống động với nhiều tính năng cảm ứng hiện đại.', 3700000.00, 63, 'img/1761465950_wGuvVArhu9.jpg', '[]', '', 1, 1, 0, '2025-10-26 08:05:50', '2025-10-26 09:43:35');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (35, 7, 'Đĩa game PS5 Call of Duty: Black Ops Cold War', 'dia-game-ps5-call-of-duty-black-ops-cold-war', 'Mô tả: Trò chơi bắn súng góc nhìn thứ nhất mang lại trải nghiệm chiến tranh lạnh chân thực và hấp dẫn', 900000.00, 32, 'img/1761466001_sfuLtEAooj.jpg', '[]', '', 1, 1, 2, '2025-10-26 08:06:41', '2025-10-26 09:58:47');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (36, 3, 'HP Pavilion 16-af0052TU', 'hp-pavilion-16-af0052tu', 'Mô tả: Laptop màn hình 16 inch lớn, thiết kế gọn nhẹ, cấu hình Intel Core i5 thế hệ mới, RAM 8GB, SSD 512GB, phù hợp đa nhiệm và làm việc văn phòng hiệu quả.', 16000000.00, 34, 'img/1761466079_CUZcgm6OyY.jpg', '[]', '', 0, 1, 0, '2025-10-26 08:07:59', '2025-10-26 09:53:52');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (37, 3, 'Dell Inspiron 14 7440 2in1', 'dell-inspiron-14-7440-2in1', 'Mô tả: Laptop kiêm tablet với thiết kế xoay 360 độ, cấu hình Intel Core i5 cao cấp, RAM 8GB, SSD 256GB, tiện lợi cho công việc linh hoạt và di chuyển.', 17000000.00, 0, 'img/1761466191_eBgperieb0.jpg', '[]', '', 0, 1, 3, '2025-10-26 08:09:51', '2025-10-26 08:20:10');
INSERT INTO products (id, category_id, name, slug, description, price, stock, image, images, specifications, is_featured, is_active, views, created_at, updated_at) VALUES (38, 3, 'Acer Aspire 3 A315', 'acer-aspire-3-a315', 'Mô tả: Laptop phổ thông giá tốt, Intel Core i5, RAM 8GB, SSD 256GB, màn hình 15.6 inch Full HD, đáp ứng ổn cho nhu cầu văn phòng và học tập.', 14000000.00, 3, 'img/1761466253_FE7wFeld0O.jpg', '[]', '', 0, 1, 0, '2025-10-26 08:10:53', '2025-10-26 09:50:25');
