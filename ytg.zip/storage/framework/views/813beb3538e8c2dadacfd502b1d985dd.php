<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Order - #') . $order->id); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <form action="<?php echo e(route('admin.orders.update', $order)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-4">
                            <label for="status" class="block text-gray-700">Order Status</label>
                            <select name="status" id="status" class="w-full px-3 py-2 border rounded" required>
                                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Pending
                                </option>
                                <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>
                                    Processing</option>
                                <option value="shipped" <?php echo e($order->status == 'shipped' ? 'selected' : ''); ?>>Shipped
                                </option>
                                <option value="delivered" <?php echo e($order->status == 'delivered' ? 'selected' : ''); ?>>Delivered
                                </option>
                                <option value="canceled" <?php echo e($order->status == 'canceled' ? 'selected' : ''); ?>>Canceled
                                </option>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label for="payment_status" class="block text-gray-700">Payment Status</label>
                            <select name="payment_status" id="payment_status" class="w-full px-3 py-2 border rounded"
                                required>
                                <option value="pending" <?php echo e($order->payment_status == 'pending' ? 'selected' : ''); ?>>
                                    Pending</option>
                                <option value="completed" <?php echo e($order->payment_status == 'completed' ? 'selected' : ''); ?>>
                                    Completed</option>
                                <option value="failed" <?php echo e($order->payment_status == 'failed' ? 'selected' : ''); ?>>Failed
                                </option>
                            </select>
                        </div>
                        <button type="submit"
                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Update
                            Order</button>
                        <a href="<?php echo e(route('admin.orders.index')); ?>" class="ml-4 text-gray-500">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Doan\pc-shop\resources\views\admin\orders\edit.blade.php ENDPATH**/ ?>