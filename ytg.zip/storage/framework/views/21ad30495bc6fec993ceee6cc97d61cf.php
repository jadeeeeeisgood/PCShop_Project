<div class="product-item">
    <div class="pi-img-wrapper">
        <img src="<?php echo e($getImageUrl()); ?>" class="img-fluid" alt="<?php echo e($product->name); ?>">

        <div class="overlay">
            <a href="<?php echo e($getImageUrl()); ?>" class="btn btn-light btn-sm me-2" data-fancybox="gallery">
                <i class="fa fa-search-plus"></i> Zoom
            </a>
            <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-eye"></i> Xem
            </a>
        </div>

        <?php if($shouldShowSticker()): ?>
            <div class="sticker <?php echo e($featured && $product->is_featured ? 'sticker-featured' : 'sticker-new'); ?>">
                <?php echo e($getStickerText()); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="p-3">
        <?php if($titleLimit): ?>
            <h6><a href="<?php echo e(route('products.show', $product)); ?>"
                    class="text-decoration-none text-dark"><?php echo e($getTitle()); ?></a></h6>
        <?php else: ?>
            <h5><a href="<?php echo e(route('products.show', $product)); ?>"
                    class="text-decoration-none text-dark"><?php echo e($getTitle()); ?></a></h5>
        <?php endif; ?>

        <div class="pi-price"><?php echo e($getFormattedPrice()); ?></div>

        <?php if($showStock || $showViews): ?>
            <div class="d-flex justify-content-between align-items-center mt-2">
                <?php if($showStock): ?>
                    <small class="text-muted">Còn: <?php echo e($product->stock); ?> sản phẩm</small>
                <?php elseif($showViews): ?>
                    <small class="text-muted">
                        <i class="fa fa-eye"></i> <?php echo e($product->views); ?> lượt xem
                    </small>
                <?php endif; ?>

                <button onclick="addToCart(<?php echo e($product->id); ?>)" class="btn add2cart btn-sm">
                    <i class="fa fa-shopping-cart"></i> <?php echo e($showStock || $showViews ? '' : 'Thêm'); ?>

                </button>
            </div>
        <?php else: ?>
            <button onclick="addToCart(<?php echo e($product->id); ?>)" class="btn add2cart mt-2">
                <i class="fa fa-shopping-cart"></i> Thêm vào giỏ
            </button>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\laragon\www\Doan\pc-shop\resources\views\components\product-card.blade.php ENDPATH**/ ?>