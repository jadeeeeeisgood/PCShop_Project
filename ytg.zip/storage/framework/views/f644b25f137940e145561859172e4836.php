<!DOCTYPE html>
<html>

<head>
    <title>Order Confirmation</title>
</head>

<body>
    <h1>Thank you for your order!</h1>
    <p>Order ID: #<?php echo e($order->id); ?></p>
    <p>Total: <?php echo e(number_format($order->total, 0, ',', '.')); ?> VNĐ</p>
    <p>Status: <?php echo e($order->status); ?></p>
    <p>Payment Method: <?php echo e($order->payment_method); ?></p>

    <h2>Order Items:</h2>
    <ul>
        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item->product->name); ?> - Quantity: <?php echo e($item->quantity); ?> - Price:
                <?php echo e(number_format($item->price, 0, ',', '.')); ?> VNĐ</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h2>Shipping Address:</h2>
    <p><?php echo e($order->customer_name); ?></p>
    <p><?php echo e($order->customer_address); ?></p>
    <p><?php echo e($order->customer_email); ?></p>

    <p>We will process your order soon!</p>
</body>

</html><?php /**PATH C:\laragon\www\Doan\pc-shop\resources\views/emails/order-confirmation.blade.php ENDPATH**/ ?>